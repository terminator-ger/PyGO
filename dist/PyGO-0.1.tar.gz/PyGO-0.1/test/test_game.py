import unittest

from pygo.Game import Game
from pygo.utils.color import  N2C, C2N, COLOR

class GameTests(unittest.TestCase):
        
    def testCountLibertiesCorner(self):
        self.game = Game()
        self.game.state[0,0] = COLOR.BLACK
        self.game.state[18,0]  = COLOR.BLACK
        self.game.state[18,18] = COLOR.WHITE
        self.game.state[0,18] = COLOR.WHITE
        mb, mw, cb, cw = self.game.__countLiberties()
        self.assertEqual(cb, 2)
        self.assertEqual(cw, 2)
        self.assertEqual(mb[0,0], 2)
        self.assertEqual(mb[18,0], 2)
        self.assertEqual(mw[18,18], 2)
        self.assertEqual(mw[0, 18], 2)


if __name__ == '__main__':
    unittest.main()