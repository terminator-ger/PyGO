from distutils.core import setup

setup(name='PyGO',
      version='0.1',
      description='Camera-based GO sgf generator',
      author='Michael Lechner',
      packages=['pygo', 'pygo.utils'],
      )
